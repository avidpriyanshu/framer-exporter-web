import React from "react";
interface Div143Props {
  framerName: any;
}
export default function Div143(props: Div143Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}