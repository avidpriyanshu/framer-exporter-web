import React from "react";
interface Div374Props {
  framerComponentType: any;
}
export default function Div374(props: Div374Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}