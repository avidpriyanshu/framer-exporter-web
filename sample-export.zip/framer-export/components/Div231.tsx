import React from "react";
interface Div231Props {
  framerComponentType: any;
}
export default function Div231(props: Div231Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}