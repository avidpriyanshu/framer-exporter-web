import React from "react";
interface Div397Props {
  framerName: any;
}
export default function Div397(props: Div397Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}