import React from "react";
interface P473Props {
  stylesPreset: any;
}
export default function P473(props: P473Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}