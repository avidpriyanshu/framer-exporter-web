import React from "react";
interface Div260Props {
  framerName: any;
}
export default function Div260(props: Div260Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}