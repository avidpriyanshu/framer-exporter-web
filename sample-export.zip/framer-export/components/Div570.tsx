import React from "react";
interface Div570Props {
  framerName: any;
}
export default function Div570(props: Div570Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}