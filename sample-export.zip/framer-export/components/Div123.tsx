import React from "react";
interface Div123Props {
  framerName: any;
}
export default function Div123(props: Div123Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}