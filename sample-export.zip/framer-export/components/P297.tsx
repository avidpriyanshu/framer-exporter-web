import React from "react";
export default function P297() {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}