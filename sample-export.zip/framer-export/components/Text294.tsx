import React from "react";
export default function Text294() {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}