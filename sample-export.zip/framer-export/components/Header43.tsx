import React from "react";
interface Header43Props {
  border: any;
  framerName: any;
}
export default function Header43(props: Header43Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}