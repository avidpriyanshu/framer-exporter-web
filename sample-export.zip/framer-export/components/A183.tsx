import React from "react";
interface A183Props {
  framerName: any;
  highlight: any;
}
export default function A183(props: A183Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}