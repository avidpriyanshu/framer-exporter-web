import React from "react";
interface Div133Props {
  framerName: any;
}
export default function Div133(props: Div133Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}