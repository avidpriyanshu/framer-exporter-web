import React from "react";
interface Div413Props {
  framerName: any;
}
export default function Div413(props: Div413Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}