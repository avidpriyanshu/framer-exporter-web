import React from "react";
interface Div576Props {
  framerName: any;
}
export default function Div576(props: Div576Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}