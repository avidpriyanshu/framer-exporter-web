import React from "react";
interface Header53Props {
  border: any;
  framerName: any;
}
export default function Header53(props: Header53Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}