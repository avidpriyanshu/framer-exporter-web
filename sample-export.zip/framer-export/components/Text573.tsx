import React from "react";
export default function Text573() {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}