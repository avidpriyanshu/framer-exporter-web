import React from "react";
interface P480Props {
  stylesPreset: any;
}
export default function P480(props: P480Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}