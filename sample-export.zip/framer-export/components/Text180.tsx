import React from "react";
export default function Text180() {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}