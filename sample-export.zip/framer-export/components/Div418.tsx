import React from "react";
interface Div418Props {
  framerName: any;
}
export default function Div418(props: Div418Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}