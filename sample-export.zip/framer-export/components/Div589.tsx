import React from "react";
interface Div589Props {
  framerName: any;
}
export default function Div589(props: Div589Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}