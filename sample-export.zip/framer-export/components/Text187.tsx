import React from "react";
export default function Text187() {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}