import React from "react";
interface Div113Props {
  framerName: any;
}
export default function Div113(props: Div113Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}