import React from "react";
interface Header7Props {
  border: any;
  framerName: any;
}
export default function Header7(props: Header7Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}