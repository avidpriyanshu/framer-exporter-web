import React from "react";
interface Div160Props {
  framerName: any;
  framerComponentType: any;
}
export default function Div160(props: Div160Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}