import React from "react";
interface Style88Props {
  framerHtmlStyle: any;
}
export default function Style88(props: Style88Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}