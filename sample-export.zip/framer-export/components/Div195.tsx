import React from "react";
interface Div195Props {
  framerName: any;
}
export default function Div195(props: Div195Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}