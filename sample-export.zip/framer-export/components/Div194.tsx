import React from "react";
interface Div194Props {
  framerName: any;
}
export default function Div194(props: Div194Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}