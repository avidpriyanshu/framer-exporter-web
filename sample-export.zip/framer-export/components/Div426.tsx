import React from "react";
interface Div426Props {
  framerName: any;
}
export default function Div426(props: Div426Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}