import React from "react";
interface Div477Props {
  framerName: any;
}
export default function Div477(props: Div477Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}