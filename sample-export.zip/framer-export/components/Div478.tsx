import React from "react";
interface Div478Props {
  framerName: any;
}
export default function Div478(props: Div478Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}