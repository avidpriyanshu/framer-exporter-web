import React from "react";
interface A300Props {
  border: any;
}
export default function A300(props: A300Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}