import React from "react";
interface Div560Props {
  framerName: any;
}
export default function Div560(props: Div560Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}