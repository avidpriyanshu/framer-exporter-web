import React from "react";
export default function Text262() {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}