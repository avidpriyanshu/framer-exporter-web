import React from "react";
interface A237Props {
  border: any;
}
export default function A237(props: A237Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}