import React from "react";
interface Div75Props {
  framerName: any;
}
export default function Div75(props: Div75Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}