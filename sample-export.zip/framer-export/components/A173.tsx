import React from "react";
interface A173Props {
  framerName: any;
  highlight: any;
}
export default function A173(props: A173Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}