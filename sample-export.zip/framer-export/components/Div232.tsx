import React from "react";
interface Div232Props {
  framerComponentType: any;
}
export default function Div232(props: Div232Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}