import React from "react";
export default function Use403() {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}