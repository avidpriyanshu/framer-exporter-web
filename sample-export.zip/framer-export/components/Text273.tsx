import React from "react";
export default function Text273() {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}