import React from "react";
interface Style2Props {
  framerHtmlStyle: any;
}
export default function Style2(props: Style2Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}