import React from "react";
interface A11Props {
  framerName: any;
  highlight: any;
  framerPageLinkCurrent: any;
}
export default function A11(props: A11Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}