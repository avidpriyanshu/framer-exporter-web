import React from "react";
interface Div98Props {
  framerName: any;
}
export default function Div98(props: Div98Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}