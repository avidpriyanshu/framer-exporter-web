import React from "react";
interface Main94Props {
  framerName: any;
}
export default function Main94(props: Main94Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}