import React from "react";
interface Div598Props {
  framerName: any;
}
export default function Div598(props: Div598Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}