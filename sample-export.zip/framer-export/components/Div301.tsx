import React from "react";
interface Div301Props {
  framerName: any;
}
export default function Div301(props: Div301Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}