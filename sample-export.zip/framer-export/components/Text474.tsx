import React from "react";
export default function Text474() {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}