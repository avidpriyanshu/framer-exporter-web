import React from "react";
interface A378Props {
  framerName: any;
}
export default function A378(props: A378Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}