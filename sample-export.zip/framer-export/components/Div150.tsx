import React from "react";
interface Div150Props {
  framerName: any;
  framerComponentType: any;
}
export default function Div150(props: Div150Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}