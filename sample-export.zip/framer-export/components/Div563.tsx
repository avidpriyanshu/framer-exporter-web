import React from "react";
interface Div563Props {
  framerName: any;
}
export default function Div563(props: Div563Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}