import React from "react";
interface Div497Props {
  framerName: any;
}
export default function Div497(props: Div497Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}