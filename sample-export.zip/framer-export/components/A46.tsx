import React from "react";
interface A46Props {
  framerName: any;
  highlight: any;
  framerPageLinkCurrent: any;
}
export default function A46(props: A46Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}