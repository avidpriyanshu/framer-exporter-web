import React from "react";
interface Div118Props {
  framerName: any;
}
export default function Div118(props: Div118Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}