import React from "react";
export default function Text336() {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}