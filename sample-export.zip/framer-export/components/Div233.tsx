import React from "react";
interface Div233Props {
  framerComponentType: any;
}
export default function Div233(props: Div233Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}