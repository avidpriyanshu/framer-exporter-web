import React from "react";
interface A33Props {
  framerName: any;
  highlight: any;
}
export default function A33(props: A33Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}