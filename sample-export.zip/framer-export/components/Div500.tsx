import React from "react";
interface Div500Props {
  framerName: any;
}
export default function Div500(props: Div500Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}