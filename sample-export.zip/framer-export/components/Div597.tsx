import React from "react";
interface Div597Props {
  framerName: any;
}
export default function Div597(props: Div597Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}