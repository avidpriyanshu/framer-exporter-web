import React from "react";
interface Div506Props {
  framerName: any;
}
export default function Div506(props: Div506Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}