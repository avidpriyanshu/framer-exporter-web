import React from "react";
interface Div96Props {
  framerName: any;
}
export default function Div96(props: Div96Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}