import React from "react";
export default function Image() {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}