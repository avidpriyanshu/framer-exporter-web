import React from "react";
interface Div281Props {
  framerName: any;
}
export default function Div281(props: Div281Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}