import React from "react";
interface Div420Props {
  framerName: any;
}
export default function Div420(props: Div420Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}