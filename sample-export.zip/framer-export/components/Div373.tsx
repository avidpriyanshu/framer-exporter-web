import React from "react";
interface Div373Props {
  framerComponentType: any;
}
export default function Div373(props: Div373Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}