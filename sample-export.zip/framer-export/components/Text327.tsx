import React from "react";
export default function Text327() {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}