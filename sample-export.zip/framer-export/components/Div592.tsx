import React from "react";
interface Div592Props {
  framerName: any;
}
export default function Div592(props: Div592Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}