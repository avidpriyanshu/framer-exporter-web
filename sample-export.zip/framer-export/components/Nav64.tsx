import React from "react";
interface Nav64Props {
  framerName: any;
}
export default function Nav64(props: Nav64Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}