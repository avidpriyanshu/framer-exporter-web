import React from "react";
interface Div280Props {
  framerName: any;
}
export default function Div280(props: Div280Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}