import React from "react";
export default function Text86() {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}