import React from "react";
interface Div108Props {
  framerName: any;
}
export default function Div108(props: Div108Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}