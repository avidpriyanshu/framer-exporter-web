import React from "react";
interface Div230Props {
  framerComponentType: any;
}
export default function Div230(props: Div230Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}