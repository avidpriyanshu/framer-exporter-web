import React from "react";
interface Div484Props {
  framerName: any;
}
export default function Div484(props: Div484Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}