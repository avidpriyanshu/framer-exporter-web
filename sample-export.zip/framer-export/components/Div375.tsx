import React from "react";
interface Div375Props {
  framerName: any;
}
export default function Div375(props: Div375Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}