import React from "react";
export default function Text298() {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}