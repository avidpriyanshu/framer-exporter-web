import React from "react";
interface Div526Props {
  framerName: any;
}
export default function Div526(props: Div526Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}