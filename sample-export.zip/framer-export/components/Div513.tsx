import React from "react";
interface Div513Props {
  framerName: any;
}
export default function Div513(props: Div513Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}