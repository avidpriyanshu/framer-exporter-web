import React from "react";
export default function Text380() {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}