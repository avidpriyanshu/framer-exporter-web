import React from "react";
interface Div138Props {
  framerName: any;
}
export default function Div138(props: Div138Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}