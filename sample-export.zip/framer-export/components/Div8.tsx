import React from "react";
interface Div8Props {
  framerName: any;
}
export default function Div8(props: Div8Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}