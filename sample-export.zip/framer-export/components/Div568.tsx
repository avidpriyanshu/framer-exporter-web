import React from "react";
interface Div568Props {
  framerName: any;
}
export default function Div568(props: Div568Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}