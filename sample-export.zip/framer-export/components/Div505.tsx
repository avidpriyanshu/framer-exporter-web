import React from "react";
interface Div505Props {
  framerName: any;
}
export default function Div505(props: Div505Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}