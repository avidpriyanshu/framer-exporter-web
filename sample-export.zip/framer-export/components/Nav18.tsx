import React from "react";
interface Nav18Props {
  framerName: any;
}
export default function Nav18(props: Nav18Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}