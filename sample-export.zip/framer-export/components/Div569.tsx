import React from "react";
interface Div569Props {
  framerName: any;
}
export default function Div569(props: Div569Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}