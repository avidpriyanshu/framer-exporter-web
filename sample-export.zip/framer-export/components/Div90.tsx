import React from "react";
interface Div90Props {
  framerRoot: any;
}
export default function Div90(props: Div90Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}