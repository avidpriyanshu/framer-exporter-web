import React from "react";
interface Div471Props {
  framerName: any;
}
export default function Div471(props: Div471Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}