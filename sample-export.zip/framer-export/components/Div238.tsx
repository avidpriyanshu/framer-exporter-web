import React from "react";
interface Div238Props {
  framerName: any;
}
export default function Div238(props: Div238Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}