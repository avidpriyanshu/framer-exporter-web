import React from "react";
interface A367Props {
  border: any;
  framerName: any;
}
export default function A367(props: A367Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}