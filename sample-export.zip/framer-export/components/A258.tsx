import React from "react";
interface A258Props {
  border: any;
}
export default function A258(props: A258Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}