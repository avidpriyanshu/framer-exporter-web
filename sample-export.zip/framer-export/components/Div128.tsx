import React from "react";
interface Div128Props {
  framerName: any;
}
export default function Div128(props: Div128Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}