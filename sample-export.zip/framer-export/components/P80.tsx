import React from "react";
export default function P80() {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}