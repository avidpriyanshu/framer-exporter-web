import React from "react";
interface A225Props {
  border: any;
  framerName: any;
}
export default function A225(props: A225Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}