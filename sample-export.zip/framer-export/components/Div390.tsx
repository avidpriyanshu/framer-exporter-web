import React from "react";
interface Div390Props {
  framerName: any;
}
export default function Div390(props: Div390Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}