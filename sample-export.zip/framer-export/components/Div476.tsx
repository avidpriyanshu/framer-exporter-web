import React from "react";
interface Div476Props {
  framerName: any;
}
export default function Div476(props: Div476Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}