import React from "react";
interface Div447Props {
  framerName: any;
}
export default function Div447(props: Div447Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}