import React from "react";
interface A26Props {
  stylesPreset: any;
}
export default function A26(props: A26Props) {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}