import React from "react";
export default function Text73() {
  return (
  <div>
  {
    /* Component content - auto-generated */
  }
  </div>
  );
}