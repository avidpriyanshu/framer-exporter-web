/** @type {import('next').NextConfig} */
const nextConfig = {
  "reactStrictMode": true,
  "images": {
    "optimization": "auto",
    "formats": [
      "image/avif",
      "image/webp"
    ]
  },
  "webpack": {
    "resolve": {
      "alias": {
        "@": "."
      }
    }
  }
};

module.exports = nextConfig;